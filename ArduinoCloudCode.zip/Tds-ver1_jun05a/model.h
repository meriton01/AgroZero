int predict(float TDS, float pH, float Soil_Moisture) {
    if (TDS <= 475.0) {
        if (pH <= 6.5) {
            if (Soil_Moisture <= 30.0) {
                return 0;  // Good condition
            } else {
                if (TDS <= 300.0) {
                    return 1;  // Bad condition
                } else {
                    return 0;  // Good condition
                }
            }
        } else {
            if (Soil_Moisture <= 45.0) {
                return 1;  // Bad condition
            } else {
                return 0;  // Good condition
            }
        }
    } else {
        if (pH <= 7.5) {
            if (Soil_Moisture <= 35.0) {
                return 1;  // Bad condition
            } else {
                return 0;  // Good condition
            }
        } else {
            return 1;  // Bad condition
        }
    }
}
